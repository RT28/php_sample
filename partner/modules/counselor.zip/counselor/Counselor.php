<?php

namespace partner\modules\counselor;

/**
 * Counselor module definition class
 */
class Counselor extends \yii\base\Module
{
    /**
     * @inheritdoc
     */
    public $controllerNamespace = 'partner\modules\counselor\controllers';

    /**
     * @inheritdoc
     */
    public function init()
    {
        parent::init();  

        // custom initialization code goes here
    }
}
