<?php

use yii\helpers\Html;
use yii\grid\GridView; 
use common\models\Student; 
use common\models\SRM; 
use common\models\Tasks;

$this->title = 'Tasks';
$this->params['breadcrumbs'][] = $this->title;
$this->context->layout = 'main';
$status = array('0'=>'Incomplete','1'=>'Completed');
?>
<div class="student-profile-main">
    
    <div class="dashboard-detail"> 
 
	 
    <?= GridView::widget([
        'dataProvider' => $dataProvider,
        'filterModel' => $searchModel, 
        'columns' => [
		 ['class' => 'yii\grid\SerialColumn'], 
		 
	[	'attribute' => 'comment',
		'value' => 'comment',
		'label' => 'Comments',  		
		 'filter'=>false,
		 'contentOptions' => ['style' => '  max-width:300px; white-space: normal; ']
		 
	],		 
	[	'attribute' => 'action',
		'value' => function($searchModel){
					$TaskActions = Tasks::TaskActions();
					return $TaskActions[$searchModel->action];
                },
		'label' => 'Action', 
		 'filter'=>false,
		 'contentOptions' => ['style' => '  max-width:100px; white-space: normal; ']
	], 
	[	'attribute' => 'status',
		'value' => function($searchModel){ 
					$TaskStatus = Tasks::TaskStatus(); 			
					return $TaskStatus[$searchModel->status];
                },
		'label' => 'Status', 
		'filter'=>false,
		'contentOptions' => ['style' => '  max-width:100px; white-space: normal; ']
	], 
	
	[	'attribute' => 'created_at',
		'value' => function($searchModel){  
				 $timestamp = strtotime($searchModel->created_at); 
				 return date('d-m-Y', $timestamp);
                 },
		'label' => 'Date',
		'filter' => false, 	
		'contentOptions' => ['style' => '  max-width:100px; white-space: normal; ']		
	], 
	[	'attribute' => false,
		'value' => function($searchModel){  
					$comment = '' ;
		 
				   if($searchModel->student_id!=0) { 
				    $studentInfo = Student::findOne(['student_id' => $searchModel->student_id]);
					  if(isset($studentInfo)){
						  return  $comment = $studentInfo->first_name." ".$studentInfo->last_name;
					  }
				  } 
				   if($searchModel->srm_id!=0) {  
						$srmInfo = SRM::findOne(['srm_id' => $searchModel->srm_id]);
						  if(isset($srmInfo)){
							  return  $comment =  $srmInfo->name;
						  }
				   }     
                 },
		'label' => 'Comment By',
		'filter' => false, 	
		'contentOptions' => ['style' => '  max-width:100px; white-space: normal; ']		
	], 
	
 
	   ['class' => 'yii\grid\ActionColumn',
			'visible' => false,
			],
			  
			
        ],
    ]); ?> 
</div> 
    
</div>
</div>
</div>
