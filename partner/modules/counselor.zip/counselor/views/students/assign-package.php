<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;
use kartik\date\DatePicker;
use common\models\Country;
use common\models\Degree;
use common\models\Majors;
use common\components\Status;

$this->context->layout = 'main';
$this->title = 'Assign Package to Student';
  
 
$status = Status::getStatus();
?>
<?php
$countryname = Country::find()->select('name')
->where(['=','id', $model->country]) 
->one();
$degree = Degree::find()->select('name')
->where(['=','id', $model->degree_preference]) 
->one();

    $majors = "";
    $countries = "";
	 
     $majors = "";
    $countries = "";
    if(!empty($model->country_preference))
    {          
        $temp = $model->country_preference;
        if (strpos($temp, ',')) {
            $arr = explode(',', $temp);            
        } else {
            $arr[] = $temp;
        }
        $arr = Country::find()->select('name')
                              ->where(['in', 'id', $arr])
                              ->asArray()
                              ->all();
        
        foreach($arr as $country) {
            $countries .= $country['name'] . ', ';
        }
    }

    if(!empty($model->majors_preference))
    {
        $temp = $model->majors_preference;
        if (strpos($temp, ',')) {
            $arr = explode(',', $temp);
        } else {
            $arr[] = $temp;
        }
        $arr = Majors::find()->select('name')
                              ->where(['in', 'id', $arr])
                              ->asArray()
                              ->all();
        
        foreach($arr as $major) {
            $majors .= $major['name'] . ', ';
        }
    }
	
	$currDate = date('Y');
$currDate1 = $currDate+1;
$currDate2 = $currDate1+1;
$begin = array($currDate,$currDate1,$currDate2);

?>
 
 <div class="consultant-dashboard-index col-sm-12">
 
 <h2>Student Information</h2>
 <div class="row">
   <div class="col-sm-3 border">
	  
		<p><strong>Email:</strong> <?=  $model->email ?></p>
		<p><strong>Country:</strong> <?= $countryname->name ?></p>
		<p><strong>Phone:</strong> <?=  $model->phone ?></p>
		<p><strong>I want to begin :</strong> <?=  $begin[$model->begin]  ?><br> <br></p> 
        </div>
	<div class="col-sm-4 border">
		<p><strong>Country Prefrences:</strong> <?= $countries ?> </p>
		<p><strong>Discipline Prefrences:</strong> <?=  $degree->name  ?></p>
		<p><strong>Majors Prefrences:</strong> <?= $majors ?> </p> 
	</div>
  
 
  </div>
  <div class="row">
  <div class="col-sm-6 border">
<?php $form = ActiveForm::begin() ?> 
 
	<?= $form->field($StudentAssignPackages, 'packagestype')->dropDownList($packages, ['prompt' => 'Select...']); ?>

	<?= $form->field($model, 'comment')->textArea(['rows' => 4]) ?>
	<div class="form-group">
	<?= Html::submitButton('Submit', ['class' => 'btn btn-primary', 'id' => 'btn-submit']) ?>
	</div>
<?php ActiveForm::end(); ?>
 </div>
  </div>
</div>