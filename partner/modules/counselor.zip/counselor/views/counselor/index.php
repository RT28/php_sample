<?php
    use yii\helpers\Html;
    use yii\helpers\Url;
    use yii\helpers\FileHelper;
    use yii\widgets\DetailView;

    $this->title = 'Profile';
    $this->context->layout = 'main';
?>
<?php
    $cover_photo_path = [];
    $src = './noprofile.gif';
    $user = $model->srm_id;
    if(is_dir("./uploads/$user/")) {
        $cover_photo_path = FileHelper::findFiles("./uploads/$user/", [
            'caseSensitive' => true,
            'recursive' => false,
            'only' => ['profile_photo.*']
        ]);
    }
    if (count($cover_photo_path) > 0) {
        $src = $cover_photo_path[0];
    }
?>

<div class="consultant-index col-xs-12">
    <div class="row">
        <h1><?= Html::encode($this->title) ?> </h1>
        <img src="<?= $src; ?>" alt="<?= $model->name ?>" style="max-height: 200px;"/>
        <a href="?r=counselor/counselor/update" class="btn btn-primary">Update</a>
        <?=
            DetailView::widget([
                'model' => $model,
                'attributes' => [
                    'name',
                    'date_of_birth',
                    'email',
                    'gender',
                    'mobile',
                   
                    'speciality',
                    'description',
                    'experience',
                    'skills'
                ],
            ]);
        ?>
    </div>
</div>