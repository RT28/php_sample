<?php
    use yii\helpers\Html;
    use yii\widgets\ActiveForm;
    use kartik\date\DatePicker;
    use kartik\file\FileInput;
    use yii\helpers\FileHelper;

    $this->title = 'Profile';
    $this->context->layout = 'main';
?>
<?php
    $initialPreview = [];
    $user = $model->srm_id;
    if (is_dir("./uploads/$user/")) {
        $cover_photo_path = FileHelper::findFiles("./uploads/$user/", [
            'caseSensitive' => true,
            'recursive' => false,
            'only' => ['profile_photo.*']
        ]);       
    
        if (count($cover_photo_path) > 0) {
            $initialPreview = [Html::img($cover_photo_path[0], ['title' => $model->name, 'class' => 'cover-photo'])];
        }
    }
?>
<div class="consultant-index col-xs-8">
    <div class="row">
        <div class="dashboard-detail">
            <?php if(isset($message) && !empty($message)): ?>
                <div class="alert alert-danger" role="alert"><?= $message ?></div>
            <?php endif; ?>
            <?php $form = ActiveForm::begin(['id' => 'consultant-registration-form', 'options' => ['enctype' => 'multipart/form-data']]) ?>
                <?= $form->field($upload, 'consultantImage')->widget(FileInput::classname(), [
                    'options' => [
                        'accept' => 'image/*'
                    ],
                    'pluginOptions' => [
                        'showUpload' => false,
                        'showPreview' => true,
                        'intialPreviewAsData' => true,
                        'resizeImages' => true,
                        'minImageWidth' => 100,
                        'initialPreview' => $initialPreview,
                        'minImageHeight' => 100,
                    ]
                ]);?>
                <?= $form->field($model, 'name')->textInput(['maxlength' => true]) ?>
                <?= $form->field($model, 'email')->textInput(['maxlength' => true]) ?>
                <?= $form->field($model, 'date_of_birth')->widget(DatePicker::classname(),[
                    'name' => 'date_of_birth',
                        'type' => DatePicker::TYPE_INPUT,
                        'pluginOptions' => [
                        'autoClose' => true,
                        'format' => 'yyyy-mm-dd'
                    ]
                ]);?>
                <?= $form->field($model, 'gender')->dropDownList(['M' => 'Male', 'F' => 'Female'], ['prompt' => 'Select']); ?>
                <?= $form->field($model, 'mobile')->textInput(['maxlength' => true]) ?>
                <?= $form->field($model, 'country')->dropDownList($countries, ['prompt' => 'Select...']); ?>
                <?= $form->field($model, 'speciality')->textArea(['rows' => 4]) ?>
                <?= $form->field($model, 'description')->textArea(['rows' => 4]) ?>
                <?= $form->field($model, 'experience')->textInput(['maxlength' => true, 'placeholder' => 'Experience in Years...']) ?>
                <?= $form->field($model, 'skills')->textArea(['rows' => 4]) ?>
                <div class="form-group">
                    <?= Html::submitButton('Update', ['class' => 'btn btn-primary', 'id' => 'btn-update']) ?>
                </div>
            <?php ActiveForm::end(); ?>
        </div>
    </div>
</div>