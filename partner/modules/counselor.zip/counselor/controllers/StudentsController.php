<?php
namespace partner\modules\counselor\controllers;

use common\models\SRM;
use common\models\StudentSrmRelation;
use common\models\Student;
use common\models\StudentEnglishLanguageProficienceyDetails;
use common\models\StudentStandardTestDetail;
use common\models\Degree;
use common\models\Majors;
use common\models\User;
use common\models\PackageType;
use yii\helpers\FileHelper;
use common\models\StudentAssociateConsultants;
use common\models\AssociateConsultants;
use common\models\StudentPackageDetails;
use yii\helpers\ArrayHelper;
use partner\models\StudentAssignPackages;
use common\components\ConnectionSettings;
use backend\models\SiteConfig;
use common\models\Country; 

use frontend\models\UserLogin;

use Yii;

class StudentsController extends \yii\web\Controller
{
    
	
	 public function actionIndex() { 
	 
		Yii::$app->view->params['activeTab'] = 'students';
	 
		$id = Yii::$app->user->identity->id;  
        $srm = SRM::find()->where(['=', 'srm_id', $id])->one();
		
		$students = StudentSrmRelation::find()->where(['=', 'student_srm_relation.srm_id', $srm->srm_id])->all();
		/*$students = StudentSrmRelation::find();
       
		$students->innerJoin('user_login', 'user_login.id = student_srm_relation.student_id');
		$students->where(['AND',['=', 'student_srm_relation.srm_id', $srm->srm_id],
		['=', 'user_login.status', UserLogin::STATUS_SUBSCRIBED]])->all();
		
		echo $students->createCommand()->rawSql;
		 echo "<pre>";
print_r($students);
echo "</pre>";
die; */
		
        $degrees = Degree::find()->orderBy('name')->all();
		$degrees = ArrayHelper::map($degrees, 'id', 'name');   
		$countries = Country::getAllCountries();
		$countries = ArrayHelper::map($countries, 'id', 'name');

		return $this->render('index', [
            'consultant' => $srm,
            'students' => $students,
			'degrees' => $degrees, 
			'countries' => $countries,
        ]);
    }

   
 public function actionAssignPackage($id) {
	 Yii::$app->view->params['activeTab'] = 'students';
	 
        $model = User::findOne($id);
		$srm = SRM::find()->where(['=', 'srm_id', $id])->one();
        $StudentAssignPackages = new StudentAssignPackages();
		$students = StudentSrmRelation::find()->where(['=', 'srm_id', $id])->all();
 
		if ($model->load(Yii::$app->request->post())) {
			
		 
			    
				$StudentAssignPackages->load(Yii::$app->request->post());
			    $StudentPD = StudentPackageDetails::find()->where(['AND',
				['=', 'student_id', $model->id],
				['=', 'package_type_id',$StudentAssignPackages->packagestype]]
				)->one();
				 
				
				if(empty($StudentPD)) {
					 $StudentPD = new StudentPackageDetails();
				}	
				$StudentPD->student_id =  $model->id;
				$StudentPD->package_type_id =  $StudentAssignPackages->packagestype; 
				
				//$StudentPD->srm_id =  $srm->id; 
				$StudentPD->created_by = Yii::$app->user->identity->username.'-'.Yii::$app->user->identity->tableName();
				$StudentPD->updated_by = Yii::$app->user->identity->username.'-'.Yii::$app->user->identity->tableName();
				$StudentPD->created_at = gmdate('Y-m-d H:i:s');
				$StudentPD->updated_at = gmdate('Y-m-d H:i:s');
				
				$consultantname = Yii::$app->user->identity->srm->name;
			 
				
				if($StudentPD->save(false)){
					
					//$model->access_code = $model->access_code;
					$model->status = UserLogin::STATUS_ACCESS_SENT;
					$model->comment = $model->comment;
					$model->save(false); 
				
					$packagestype = $StudentPD->package_type_id ;
					$user = $model->first_name. ' '.  $model->last_name; 

					if($this->sendActivationLink($model->id, $model->email, $user,$consultantname,$packagestype)) {
						 return $this->redirect(['students/index'],['status' => 'success', 'id' => $model->id]);
					}
				}	
			  
		}	 
        return $this->render('assign-package', [
            'model' => $model, 
			'StudentAssignPackages' => $StudentAssignPackages, 			
            'packages' =>  PackageType::getPackageType(),
			'students' => $students,
			'srm' => $srm,
        ]);
    }

	private function sendActivationLink($id, $email,$name,$consultantname,$packagestype) {
		$cc = SiteConfig::getConfigGeneralEmail();
		$from = SiteConfig::getConfigFromEmail();	
				
        $time = time();
        Yii::$app->mailer->compose(['html' => '@common/mail/dashboard_access'],[
                'user' => $name,
				'consultantname' => $consultantname,
				'packagestype' => $packagestype,
                'link' => ConnectionSettings::BASE_URL . 'frontend/web/index.php?r=site/activate-dashboard&id=' . $id . '&ptid=' . $packagestype . '&timestamp=' . strtotime('+2 days', $time)
            ])
            ->setFrom($from)
            ->setTo($email)
			->setCc($cc)
            ->setSubject('GoToUniversity Dashboard Access Link')
            ->send();
        return true;
    }
	
    public function actionView($id) {
		
	   Yii::$app->view->params['activeTab'] = 'students';
        $model = Student::findOne($id);
        $englishTests = StudentEnglishLanguageProficienceyDetails::find()->where(['=', 'student_id', $model->student_id])->all();
        $standardTests = StudentStandardTestDetail::find()->where(['=', 'student_id', $model->student_id])->all();
        $associates = StudentAssociateConsultants::find()->where(['=','student_id', $model->student_id])->all();
        $consultantAssociates = AssociateConsultants::find()->where(['=', 'parent_consultant_id', Yii::$app->user->identity->id])->all();
        $packages = StudentPackageDetails::find()->where(['=', 'student_id', $model->student_id])->all();

        return $this->render('view', [
            'model' => $model,
            'englishTests' => $englishTests,
            'standardTests' => $standardTests,
            'associates' => $associates,
            'consultantAssociates' => $consultantAssociates,
            'packages' => $packages
        ]);
    }

	

    public function actionDisconnect() {
        $student = $_POST['student'];
        $id = Yii::$app->user->identity->id;

        // disconnect all accosiates first.

        $associates = StudentSrmRelation::find()->where(['AND', ['=', 'student_id', $student], ['=', 'parent_consultant_id', $id]])->all();

        if(sizeof($associates) > 0) {
            $transaction = \Yii::$app->db->beginTransaction();
            $count = StudentSrmRelation::deleteAll(['AND', ['=', 'student_id', $student], ['=', 'parent_consultant_id', $id]]);
            if ($count == sizeof($associates)) {
                $model = StudentSrmRelation::find()->where(['AND', ['=', 'student_id', $student], ['=', 'consultant_id', Yii::$app->user->identity->id]])->one();
                if(empty($model)) {
                    $transaction->rollBack();
                    return json_encode(['status' => 'error', 'message' => 'Error disconneting consultant. No relation found']);
                }
                if ($model->delete()) {
                    $transaction->commit();
                    return json_encode(['status' => 'success']);
                }
                $transaction->rollBack();
                return json_encode(['status' => 'error', 'message' => 'Error disconneting consultant. No relation found']);
            } else {
                $transaction->rollBack();
                return json_encode(['status' => 'error', 'message' => 'Error disconnecting one or more associates']);
            }
        }
    }
}
