<?php

namespace partner\modules\counselor\controllers;

use Yii;
use common\models\Tasks;
use common\models\SRM;
use common\models\UserLogin;
use partner\modules\counselor\models\TasksSearch;
use common\models\TaskCategory;
use common\models\TaskList; 
use common\models\TaskComment;
use common\models\StudentSrmRelation;
use backend\models\SiteConfig;
use common\models\Student;
use yii\web\Controller;
use yii\web\NotFoundHttpException;
use yii\filters\VerbFilter;
use yii\helpers\Json;
use yii\data\ActiveDataProvider;
use yii\filters\AccessControl; 
use common\components\AccessRule;
use common\components\Roles; 
use common\models\FileUpload;
use yii\web\UploadedFile;
use yii\helpers\FileHelper;
use yii\helpers\ArrayHelper;
use common\components\ConnectionSettings;
use yii\widgets\Pjax;
use yii\widgets\ActiveForm;
 
class TasksController extends Controller
{
    /**
     * @inheritdoc
     */
    public function behaviors()
    {
        return [
            'verbs' => [
                'class' => VerbFilter::className(),
                'actions' => [
                    'delete' => ['POST'],
                ],
            ],
        ];
    }

    /**
     * Lists all StudentTasks models.
     * @return mixed
     */
	 
    public function actionIndex()
    {
		 Yii::$app->view->params['activeTab'] = 'tasks';
        
         
		$id = Yii::$app->user->identity->id;   
		 
        $searchModel = new TasksSearch(); 		
		$query = TasksSearch::find()->where(['srm_id'=>$id]);
        $dataProvider = $searchModel->search(Yii::$app->request->queryParams);
	  
		
        return $this->render('index', [
            'searchModel' => $searchModel,
            'dataProvider' => $dataProvider,
			'TaskStatus' => Tasks::TaskStatus(), 
			'TaskActions' => Tasks::TaskActions(),
			'TaskResponsbility' => Tasks::TaskResponsbility(),
			'TaskSpecificAlert' => Tasks::TaskSpecificAlert(), 
			'VerificationByCounselor' => Tasks::TaskVerificationByCounselor(),
			'students' => $this->getAllAssignedStudent(),
        ]);
    }

    
    public function actionView()
    {
		$id=$_POST['id'];
		$model = $this->findModel($id);
 
 
		//$status = Tasks::TaskStatus();
		
		//$taskStatus = $this->getStatus($status);
		 
	 
        return $this->renderAjax('view', [
            'model' => $model, 
        ]);
    }

	/* private function getStatus($status,$values)
    {
		$data = explode(',',$values);
		foreach($data as $value){
			if (array_key_exists($value, $status)) {
			$status []=  $status[$value];
		}
		} 
		
		return $status;
		
	}*/
 
    public function actionCreate()
    {
		//Yii::$app->view->params['activeTab'] = 'tasks';
        $model = new Tasks();
		$upload = new FileUpload();
		$id = Yii::$app->user->identity->id;  
		
	 
		 if (Yii::$app->request->isAjax && $model->load(Yii::$app->request->post())) {
			Yii::$app->response->format = \yii\web\Response::FORMAT_JSON;  
				return Json::encode(ActiveForm::validate($model)); 
			
		 } 
	  if ($model->load(Yii::$app->request->post())) {
		 
				$model->srm_id = Yii::$app->user->identity->id; 
				$model->created_by = Yii::$app->user->identity->id;
				$model->updated_by = Yii::$app->user->identity->id;
				$model->created_at = gmdate('Y-m-d H:i:s');
				$model->updated_at = gmdate('Y-m-d H:i:s');
	 
			 
				if(isset($_POST['Tasks']['notified'])) {
					$model->notified = implode(',', $_POST['Tasks']['notified']);
				}
							 
				if(!empty($model->task_list_id) || $model->task_list_id!=0){
					$task = TaskList::find()->where(['=', 'id', $model->task_list_id])->one();
					$model->title = $task->name;
				} 
				
				if($model->save(false)){
				 
					$comment = new TaskComment();
					$comment->task_id =$model->id;
					$comment->srm_id =$model->srm_id;
					$comment->action =$model->action;
					$comment->status =$model->status;
					$comment->comment =$model->comments;
					$comment->created_by = $model->updated_by;
					$comment->created_at = $model->updated_at;
					$comment->save(false);
					$subject = 'Task has been assigned to you.'; 
					$this->sendMail($model,$subject);
			 
					$this->saveUploadAttachment($upload, $model);
				}
				 
				return $this->redirect(['index']);
			 	
        } else {
            return $this->renderAjax('create', [
                'model' => $model,
				'TaskCategories' => TaskCategory::getAllTaskCategories(),
				'TasksList' => TaskList::getAllTaskList(),
				'upload' => $upload,
				'TaskStatus' => Tasks::TaskStatus(),
				'TaskActions' => Tasks::TaskActions(),
				'TaskResponsbility' => Tasks::TaskResponsbility(),
				'TaskSpecificAlert' => Tasks::TaskSpecificAlert(), 
				'students' => $this->getAllAssignedStudent(),
				'VerificationByCounselor' => Tasks::TaskVerificationByCounselor(),
            ]);
        }
    }
 
   public function actionUpdate($id)
    {
		 
		
		Yii::$app->view->params['activeTab'] = 'tasks';
        $model = $this->findModel($id);
		$upload = new FileUpload();

		 if (Yii::$app->request->isAjax && $model->load(Yii::$app->request->post())) {
			Yii::$app->response->format = \yii\web\Response::FORMAT_JSON;  
				return Json::encode(ActiveForm::validate($model)); 
			
		 }  
		  
          if ($model->load(Yii::$app->request->post())) {
			$model->srm_id = Yii::$app->user->identity->id; 
			$model->updated_by = Yii::$app->user->identity->username.'-'.Yii::$app->user->identity->tableName();
			$model->updated_at = gmdate('Y-m-d H:i:s');
			
			if(isset($_POST['Tasks']['notified'])) {
                $model->notified = implode(',', $_POST['Tasks']['notified']);
			}
			
			if(!empty($model->task_list_id) || $model->task_list_id!=0){
				$task = TaskList::find()->where(['=', 'id', $model->task_list_id])->one();
				$model->title = $task->name;
			}
		 
			if($model->save(false)){
				
				$comment = new TaskComment();
				$comment->task_id =$model->id;
				$comment->srm_id =$model->srm_id;
				$comment->action =$model->action;
				$comment->status =$model->status;
				$comment->comment =$model->comments;
				$comment->created_by = $model->updated_by;
			 	$comment->created_at = $model->updated_at;
				$comment->save(false);
				$subject = 'Task has been updated.'; 
				$this->sendMail($model,$subject);
		 
				 $this->saveUploadAttachment($upload, $model);
			}
			 
            return $this->redirect(['index']);
        } else {
            return $this->renderAjax('update', [
                'model' => $model,
				'TaskCategories' => TaskCategory::getAllTaskCategories(),
				'TasksList' => TaskList::getAllTaskList(),
				'upload' => $upload,
				'TaskStatus' => Tasks::TaskStatus(),
				'TaskActions' => Tasks::TaskActions(),
				'TaskResponsbility' => Tasks::TaskResponsbility(),
				'TaskSpecificAlert' => Tasks::TaskSpecificAlert(), 
				'VerificationByCounselor' => Tasks::TaskVerificationByCounselor(),
				'students' => $this->getAllAssignedStudent(),
            ]);
        }
    }
	
	private function sendMail($model, $subject){
	
	$Toemail = array();	
	$studentProfile = Student::find()->where(['=', 'student_id', $model->student_id])->one();
	$studentname = $studentProfile->first_name." ".$studentProfile->last_name;

	$Toemail[] = $studentProfile->email; 
	if(!empty($model->notified)){
		$notifiedTo = 	explode(',',$model->notified);
		
		if(in_array(3, $notifiedTo)){ 
			if(!empty($studentProfile->parent_email)){
				$Toemail[] = $studentProfile->parent_email; 
			}
		}
		if(in_array(4, $notifiedTo)){ 
			if(!empty($model->additional)){
				$Toemail[] = $model->additional; 
			}
		}
	} 
	 
	$Toemail[] = Yii::$app->user->identity->srm->email;  
	
	$catName = '';
	$masterCategory = TaskCategory::find()->where(['=', 'id', $model->task_category_id])->one();
	if(!empty($masterCategory)){
		$catName = $masterCategory->name;
	}

	$ListName = '';
	$taskList = TaskList::find()->where(['=', 'id', $model->task_list_id])->one();
	if(!empty($taskList)){
		$ListName = $taskList->name;
	}
 
	    $cc = SiteConfig::getConfigGeneralEmail();
		$from = SiteConfig::getConfigFromEmail();		
		//$Toemail =  implode(',',$Toemail); 
		 
		$mail = Yii::$app->mailer->compose(['html' => '@common/mail/task_by_srm'],
			['studentname' => $studentname,
			 'catName' =>$catName,
			 'ListName' =>$ListName,
			 'model' =>$model,
			])
			->setFrom($from)
			->setTo($Toemail)
			->setCc($cc)
			->setSubject($subject);
	 
		 if($mail->send()){
			 return true;
		 }else{
			  return false;
		 } 
			
   }

	private function getAllAssignedStudent() {
		 $id = Yii::$app->user->identity->id;  
		$students = StudentSrmRelation::find()
        ->leftJoin('user_login', 'user_login.id = student_srm_relation.student_id') 
		->where('student_srm_relation.srm_id = '.$id . ' AND  user_login.status = 4')
		->all();
	 
		
		$studentData = array();		
		$i = 0;				 
		foreach($students as $student){
 	
		$studentProfile = $student->student->student;	
		$studentData[$i]['id'] = $studentProfile->student_id;	
		$studentData[$i]['name'] =  $studentProfile->first_name." ".$studentProfile->last_name;
		
		$i++;
		}
		 
		$studentList = ArrayHelper::map($studentData, 'id', 'name');
		return $studentList;
	}	
	private function saveUploadAttachment($upload, $model) {
        $newFile = UploadedFile::getInstance($upload, 'attachment');
	 
        if (isset($newFile)) {
            $upload->attachment = $newFile;
			$filename = $upload->uploadSrmTask($model);			
         	 
			if(isset($filename)){
		
            if(!empty($model)) {			 
					$model->updated_by = Yii::$app->user->identity->id;
					$model->updated_at = gmdate('Y-m-d H:i:s'); 
					$model->attachment = $filename; 
					$model->save(false); 
			} 	    
					return true;
            } else {
                return false;
            }
        }
        return true;
    }
	
	 

	public function actionDownload($id,$name) {
        ini_set('max_execution_time', 5*60); // 5 minutes
		$filepath = Yii::getAlias('@frontend'); 
        $fileName = $name;
        if (is_dir($filepath."/web/uploads/tasks/$id")) {
            $path = FileHelper::findFiles($filepath."/web/uploads/tasks/$id", [
                'caseSensitive' => false,
                'recursive' => false,
                'only' => [$fileName]
            ]);
            if (count($path) > 0) {
                Yii::$app->response->sendFile($path[0]);
            }
        }
    }
	
	public function actionReminder($id) {
		 
		$model = $this->findModel($id);
		$subject= 'Task Reminder';
		  
		  /* if($this->sendMail($model,$subject)) {
				  
				 return 'Reminder sent.';
		   }else {
			   return 'Error in sending Reminder.';
        
		  }*/ 
		   if($this->sendMail($model,$subject)==true) {
			  
				 return json_encode(['status' => 'success', 'message' => 'Reminder sent.']);
				 exit;
		   }else{ 
			   return json_encode(['status' => 'error', 'message' => 'Error in sending Reminder.']);
			   exit;
		   }
    }
	 
	
    public function actionDelete($id)
    {
        $this->findModel($id)->delete();

        return $this->redirect(['index']);
    }
	
	public function actionList() {
        if (isset($_POST['task_category_id'])) {
           $task_category_id = $_POST['task_category_id']; 
            $majors = TaskList::find()->where(['=', 'task_category_id', $task_category_id])->all();
           
		   return Json::encode(['result'=>$majors, 'status' => 'success']);
        }
        return Json::encode(['result'=>[], 'status' => 'failure']);
    }

    public function actionSubcat() {
        $out = [];
        if (isset($_POST['depdrop_parents'])) {
        $parents = $_POST['depdrop_parents'];

            if ($parents != null) {
                $cat_id = $parents[0];
                $selected = '';

                $out = TaskList::find()
                ->where(['task_category_id'=>$cat_id])
                ->select(['id as id','name as name'])
                ->orderBy('name')
                ->asArray()->all();
				if(!empty($out)){
					array_push($out,['id'=>'0', 'name'=>'Others']);  
				}
                echo Json::encode(['output'=>$out, 'selected'=>'selected']);
                return;
            }
        }
        echo Json::encode(['output'=>'', 'selected'=>'']);
    }

   
    protected function findModel($id)
    {
        if (($model = Tasks::findOne($id)) !== null) {
            return $model;
        } else {
            throw new NotFoundHttpException('The requested page does not exist.');
        }
    }
}

