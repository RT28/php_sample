<?php
namespace partner\modules\counselor\controllers;

use Yii;
use partner\models\PartnerLogin;
use partner\models\CounselorEnquiry;
use common\models\SRM;
use common\models\Consultant;
use common\models\Country;
use common\models\Degree;
use yii\helpers\ArrayHelper;
use common\components\Status;
use common\components\Roles;
use common\models\FileUpload;
use yii\web\UploadedFile;
use common\models\Others;
use yii\helpers\Json;
use common\models\SrmCalendar;
use frontend\models\StudentCalendar;
use common\models\CalendarSessionTokenRelation;
use common\components\CalendarEvents;
use OpenTok\OpenTok;
use OpenTok\MediaMode;
use common\components\ConnectionSettings;

class CounselorController extends \yii\web\Controller
{

    public function actionIndex() {
		  Yii::$app->view->params['activeTab'] = 'dashboard';
        $model = Yii::$app->user->identity->srm;
        return $this->render('index', [
            'model' => $model
        ]);
    }

    public function actionCreate()
    {
		$model = new CounselorEnquiry();	 
        
        $partnerLogin = new PartnerLogin();
        $countries = ArrayHelper::map(Country::find()->orderBy(['name' => 'ASC'])->all(), 'id', 'name');
        //$degrees = Degree::find()->orderBy('name')->all();
		$message = '';
        if(Yii::$app->request->post()) {
            $partnerLogin->load(Yii::$app->request->post());
            $exists = PartnerLogin::find()->where(['=', 'email', $partnerLogin->email])->one();
           
			if(empty($exists)) {
				$model->load(Yii::$app->request->post()); 
				$partnerLogin->username = $partnerLogin->email;
                //$partnerLogin->setPassword($partnerLogin->password_hash);
				// $partnerLogin->generatePasswordResetToken();
               // $partnerLogin->generateAuthKey();
               
				$partnerLogin->created_at = gmdate('Y-m-d H:i:s');
                $partnerLogin->updated_at = gmdate('Y-m-d H:i:s');				
				$partnerLogin->status = Status::STATUS_NEW;
				
				
				
				if($model->choosesrm==0){
					$partnerLogin->role_id = Roles::ROLE_SRM; 
					
                    $srm = new SRM(); 
					$srm->name = $model->name;
					$srm->email = $partnerLogin->email;
					$srm->date_of_birth = $model->date_of_birth;
					$srm->gender = $model->gender;
					$srm->description = $model->description;
					$srm->mobile = $model->mobile;
					$srm->country = $model->country;
					$srm->speciality = $model->speciality;
					$srm->experience = $model->experience;
					$srm->skills = $model->skills;
					 
				}
				
                if($model->choosesrm==1){
					$partnerLogin->role_id = Roles::ROLE_CONSULTANT;
					
					$Consultant = new Consultant(); 
					$Consultant->name = $model->name;
					$Consultant->email = $partnerLogin->email;
					$Consultant->date_of_birth = $model->date_of_birth;
					$Consultant->gender = $model->gender;
					$Consultant->description = $model->description;
					$Consultant->mobile = $model->mobile;
					$Consultant->country_id = $model->country;
					$Consultant->speciality = $model->speciality;
					$Consultant->experience = $model->experience;
					$Consultant->skills = $model->skills; 		
					 
				}
				 
				
                if($partnerLogin->save(false)) {
				
					
					
					if($model->choosesrm==0){ 
						$srm->srm_id = $partnerLogin->id;	
 					
					$srm->created_at = gmdate('Y-m-d H:i:s');
					$srm->updated_at = gmdate('Y-m-d H:i:s');
					$srm->created_by = $partnerLogin->id;
					$srm->updated_by = $partnerLogin->id;
					
						if($srm->save()) {
							$message = 'Success! Registration successfull';
						} else {
							$message = 'Error! Error processing your request. Please contact Administrator';
						}
					}
					
					 
					if($model->choosesrm==1){  						 
						$Consultant->consultant_id = $partnerLogin->id;									
						$Consultant->created_at = gmdate('Y-m-d H:i:s');
						$Consultant->updated_at = gmdate('Y-m-d H:i:s');
						$Consultant->created_by = $partnerLogin->id;
						$Consultant->updated_by = $partnerLogin->id;
					
							if($Consultant->save()) {								
								$message = 'Success! Registration successfull';
							} else {
								$message = 'Error! Error processing your request. Please contact Administrator';
							}
						} 
						
						
						
                } else {
                    $message = 'Error! Error processing your request. Please contact administrator';
                } 
            } else {
                $message = 'Error! Email already exists';
            }
        }
		 
        return $this->render('create', [
            'model' => $model,
            'partnerLogin' => $partnerLogin,
            'countries' => $countries,
			'degrees' => Degree::getAllDegrees(),
            'message' => $message
        ]);
    }

	public function actionView()
    {
		$id=$_POST['id'];
		$model = $this->findModel($id);
  
	 
        return $this->renderAjax('view', [
            'model' => $model, 
        ]);
    }

	 
	
    public function actionDelete()
    {
        return $this->render('delete');
    }

    public function actionUpdate()
    {
		 Yii::$app->view->params['activeTab'] = 'profile';
		 
        $model = Yii::$app->user->identity->srm;
        $upload = new FileUpload();
        $countries = ArrayHelper::map(Country::find()->orderBy(['name' => 'ASC'])->all(), 'id', 'name');
        $message = '';
        if($model->load(Yii::$app->request->post())) {
            if ($model->save()) {
                if($this->saveProfilePicture($upload, Yii::$app->user->identity)) {
                    return $this->redirect(['counselor/index']);
                }
                $message = 'Error updating profile picture.';
            }
            $message = 'Error updating profile.';
        }
        return $this->render('update', [
            'model' => $model,
            'countries' => $countries,
            'upload' => $upload,
            'message' => $message
        ]);
    }

    private function saveProfilePicture($image, $consultant) {
        $newFile = UploadedFile::getInstance($image, 'consultantImage');
        if (isset($newFile)) {
            $image->consultantImage = UploadedFile::getInstance($image, 'consultantImage');
            if ($image->uploadConsultantImage($consultant)) {
                return true;
            } else {
                return false;
            }
        }
        return true;
    }

    public function actionGetEventTypes() {
        $name = 'event_type';
        $model = [];
        if (($model = Others::findBySql('SELECT value FROM others WHERE name="' . $name . '"')->one()) !== null) {
            $model = explode(',', $model->value);
            return Json::encode(['status' => 'success', 'response' => $model]);
        }
        return Json::encode(['status' => 'error', 'response' => 'Error fetching others']);
    }

    public function actionGetSrmCalendar() {
        $start = $_POST['start'];
        $end = $_POST['end'];
        $id = Yii::$app->user->identity->id;

        $events = SrmCalendar::find()->where(['and', "start >= '$start'", "end <= '$end'", "srm_id=$id"])->all();

        return Json::encode(['status' => 'success' ,'response' => $events]);
    }    

    public function actionAddEvent() {
        $event = new SrmCalendar();
        $appointment = null;
        $role = null;
        if(isset($_POST['appointment_with'])) { 
            $appointment = $_POST['appointment_with'];
            $role = $_POST['appointment_role'];
        }
        $value = $this->validateEventBeforeAdd($_POST['start'], $_POST['end'], $_POST['event_type'], $appointment, $role);

        if($value !== true) {
            return Json::encode($value);
        }

        $event->srm_id = Yii::$app->user->identity->id;
        $event->title = $_POST['title'];
        $event->start = $_POST['start'];
        $event->end = $_POST['end'];
        $event->event_type = $_POST['event_type'];
        $event->created_by = Yii::$app->user->identity->id;
        $event->updated_by = Yii::$app->user->identity->id;
        $event->updated_at = gmdate('Y-m-d H:i:s');
        $event->created_at = gmdate('Y-m-d H:i:s');
        $event->time_stamp = gmdate('U');
        if(isset($_POST['url'])) {
            $event->url = $_POST['url'];
        }

        if(isset($_POST['remarks'])) {
            $event->remarks = $_POST['remarks'];
        }

        if($event->event_type == CalendarEvents::EVENT_MEETING) {
            $event->appointment_status = CalendarEvents::EVENT_STATUS_PENDING;
        }

        if($event->save(false)) {
            if(isset($role)) {
                if($role == Roles::ROLE_STUDENT) {
                    $student_event = new StudentCalendar();
                    $student_event->student_id = $appointment;
                    $student_event->srm_appointment_id = $event->id;
                    $student_event->event_type = $event->event_type;
                    $student_event->appointment_status = $event->appointment_status;
                    $student_event->title = $event->title;
                    $student_event->remarks = $event->remarks;
                    $student_event->start = $event->start;
                    $student_event->end = $event->end;
                    $student_event->time_stamp = $event->time_stamp;
                    $student_event->created_by = $event->created_by;
                    $student_event->created_at = $event->created_at;
                    $student_event->updated_by = $event->updated_by;
                    $student_event->updated_at = $event->updated_at; 
                    if($student_event->save()) {
                        $event->student_appointment_id = $student_event->id;
                        if($event->save()) {
                            return Json::encode(['status' => 'success' ,'response' => $event]);
                        } else {
                            return Json::encode(['status' => 'failure' ,'response' => $event, 'message' => 'Error while saving student appointment in student calendar.']);
                        }
                    } else {
                        return Json::encode(['status' => 'failure' ,'response' => $event, 'message' => 'Error while saving student appointment in srm calendar.']);
                    }
                }
            } else {
                return Json::encode(['status' => 'success' ,'response' => $event]);
            }
        }
        return Json::encode(['status' => 'failure' ,'response' => $event,'message' => 'Error while saving student appointment.']);
    }

    public function actionUpdateEvent() {
        $id = $_POST['id'];
        $event = SrmCalendar::findOne($id);
        $appointment = null;
        $role = null;
        if(isset($_POST['appointment_with'])) {
            $appointment = $_POST['appointment_with'];
            $role = $_POST['appointment_role']; 
        }
        $value = $this->validateEventBeforeUpdate($_POST['start'], $_POST['end'], $_POST['event_type'], $appointment, $role, $event);

        if($value !== true) {
            return Json::encode($value);
        }

        $event->srm_id = Yii::$app->user->identity->id;
        $event->title = $_POST['title'];
        $event->start = $_POST['start'];
        $event->end = $_POST['end'];
        $event->event_type = $_POST['event_type'];
        $event->time_stamp = gmdate('U');
        $event->created_by = Yii::$app->user->identity->id;
        $event->updated_by = Yii::$app->user->identity->id;
        $event->updated_at = gmdate('Y-m-d H:i:s');
        $event->created_at = gmdate('Y-m-d H:i:s');
        if(isset($_POST['url'])) {
            $event->url = $_POST['url'];
        }

        if(isset($_POST['remarks'])) {
            $event->remarks = $_POST['remarks'];
        }

        if($event->event_type == CalendarEvents::EVENT_MEETING) {
            $event->appointment_status = CalendarEvents::EVENT_STATUS_PENDING;
        }

        if($event->save()) {
            if(isset($role)) {
                if($role == Roles::ROLE_STUDENT) {
                    if (isset($event->student_appointment_id)) {
                        $student_event = StudentCalendar::findOne($event->student_appointment_id);
                    } else {
                        $student_event = new StudentCalendar();
                    }
                    $student_event->student_id = $appointment;
                    $student_event->srm_appointment_id = $event->id;
                    $student_event->event_type = $event->event_type;
                    $student_event->appointment_status = $event->appointment_status;
                    $student_event->title = $event->title;
                    $student_event->remarks = $event->remarks;
                    $student_event->start = $event->start;
                    $student_event->end = $event->end;
                    $student_event->time_stamp = $event->time_stamp;
                    $student_event->created_by = $event->created_by;
                    $student_event->created_at = $event->created_at;
                    $student_event->updated_by = $event->updated_by;
                    $student_event->updated_at = $event->updated_at; 
                    if($student_event->save()) {
                        $event->student_appointment_id = $student_event->id;
                        if($event->save()) {
                            return Json::encode(['status' => 'success' ,'response' => $event, 'message' => 'complete']);
                        } else {
                            return Json::encode(['status' => 'failure' ,'response' => $event, 'message' => 'Error while saving counsellor appointment in student calendar.']);
                        }
                    } else {
                        return Json::encode(['status' => 'failure' ,'response' => $event, 'message' => 'Error while saving counsellor appointment in srm calendar.']);
                    }
                }
            } else {
                return Json::encode(['status' => 'success' ,'response' => $event, 'message' => 'role not set']);
            }
        }
        return Json::encode(['status' => 'failure' ,'response' => $event,'message' => 'Error while saving student appointment.']);
    }

    public function actionDeleteEvent() {
        $transaction = \Yii::$app->db->beginTransaction();
        $id = $_POST['id'];
        $event = SrmCalendar::findOne($id);
        $delete_main_event = false;
        if(isset($event->student_appointment_id)) {
            $student_event = StudentCalendar::findOne($event->student_appointment_id);
            if(empty($student_event)) {
                $delete_main_event = true;
            } else {
                if($student_event->delete()) {
                    $delete_main_event = true;
                }
            }
        } else {
            $delete_main_event = true;
        }
        if ($delete_main_event) {
            if($event->delete()) {
                $transaction->commit();
                return Json::encode(['status' => 'success' ,'response' => '']);
            }
        }
        $transaction->rollBack();
        return Json::encode(['status' => 'failure' ,'response' => 'Error deleting event']);
    }

    private function getOthers($name) {
        $model = [];
        if (($model = Others::findBySql('SELECT value FROM others WHERE name="' . $name . '"')->one()) !== null) {
            $model = explode(',', $model->value);
            return $model;
        }
    }

    private function validateEventBeforeAdd($start, $end, $event_type, $appointment, $role) {
        $event_availablity = CalendarEvents::EVENT_UNAVAILABILITY;
        $event_appointment = CalendarEvents::EVENT_MEETING;
        if($event_type != $event_appointment && $event_type != $event_availablity) {
            return true;
        }
        /**
            * condition 1: new event starts after the event and ends after event.
            * condition 2: new event starts before event and ends before event ends. *
            * condition 3: new event starts before event and ends after event.
            * condition 4: new event starts before start and ends in between. *
        */
        $srm_id = Yii::$app->user->identity->id;
        $query = "SELECT * FROM srm_calendar WHERE srm_id=$srm_id AND (event_type=$event_availablity OR event_type=$event_appointment) AND ((start > '$start' AND end > '$end' AND end < '$start') OR (start > '$start' AND end <= '$end') OR (start <= '$start' AND end > '$end') OR (start <= '$start' AND end > '$start' AND end <= '$end') OR (start = '$start' AND end = '$end'))";
        $models = SrmCalendar::findBySql($query);
        
        if(!$models->exists()) {
            if($event_type == $event_appointment) {
                if ($role == Roles::ROLE_STUDENT) {
                    $query = "SELECT * FROM student_calendar WHERE student_id=$appointment AND (event_type=$event_availablity OR event_type=$event_appointment) AND ((start > '$start' AND end > '$end' AND end < '$start') OR (start > '$start' AND end <= '$end') OR (start <= '$start' AND end > '$end') OR (start <= '$start' AND end > '$start' AND end <= '$end') OR (start = '$start' AND end = '$end'))";
                    $models = StudentCalendar::findBySql($query);

                    if(!$models->exists()) {
                        return true;
                    } else {
                        foreach($models->each() as $model) {
                            if ($model->event_type == $event_availablity) {
                                return ['status' => 'error', 'message' => ['You\'r student is unavailable from ' . $model->start . ' to ' . $model->end]];
                            }
                            if ($model->event_type == $event_appointment) {
                                return ['status' => 'error', 'message' => ['You\'r student is unavailable from ' . $model->start . ' to ' . $model->end]];
                            }
                        }
                    }
                }
            }
            return true;
        }
        else {
            foreach($models->each() as $model) {
                if ($model->event_type == $event_availablity) {
                    return ['status' => 'error', 'message' => ['You\'ve marked yourself unavailable for from ' . $model->start . ' to ' . $model->end . '.']];
                }
                if ($model->event_type == $event_appointment) {
                    return ['status' => 'error', 'message' => ['You have a appointment scheduled between ' . $model->start . ' to ' . $model->end . '.']];
                }
            }
        }
    }

    private function validateEventBeforeUpdate($start, $end, $event_type, $appointment, $role, $current_event) {
        $event_availablity = CalendarEvents::EVENT_UNAVAILABILITY;
        $event_appointment = CalendarEvents::EVENT_MEETING;
        
        $srm_id = Yii::$app->user->identity->id;
        $query = "SELECT * FROM srm_calendar WHERE id <> $current_event->srm_id AND srm_id=$srm_id AND (event_type=$event_availablity OR event_type=$event_appointment) AND ((start > '$start' AND end > '$end' AND end < '$start') OR (start > '$start' AND end <= '$end') OR (start <= '$start' AND end > '$end') OR (start <= '$start' AND end > '$start' AND end <= '$end') OR (start = '$start' AND end = '$end'))";

        $models = SrmCalendar::findBySql($query);

        if(!$models->exists()) {
            if($event_type == $event_appointment) {
                if ($role == Roles::ROLE_STUDENT) {
                    $query = "SELECT * FROM student_calendar WHERE id <> $current_event->student_appointment_id AND student_id=$appointment AND (event_type=$event_availablity OR event_type=$event_appointment) AND ((start > '$start' AND end > '$end' AND end < '$start') OR (start > '$start' AND end <= '$end') OR (start <= '$start' AND end > '$end') OR (start <= '$start' AND end > '$start' AND end <= '$end') OR (start = '$start' AND end = '$end'))";
                    $models = StudentCalendar::findBySql($query);

                    if(!$models->exists()) {
                        return true;
                    } else {
                        foreach($models->each() as $model) {
                            if ($model->event_type == $event_availablity) {
                                return ['status' => 'error', 'message' => ['You\'r student is unavailable from ' . $model->start . ' to ' . $model->end]];
                            }
                            if ($model->event_type == $event_appointment) {
                                return ['status' => 'error', 'message' => ['You\'r student is unavailable from ' . $model->start . ' to ' . $model->end]];
                            }
                        }
                    }
                }
            }
            return true;
        }
        else {            
            foreach($models->each() as $model) {
                if ($model->event_type == $event_availablity) {
                    return ['status' => 'error', 'message' => ['You\'ve marked yourself unavailable for from ' . $model->start . ' to ' . $model->end . '.']];
                }
                if ($model->event_type == $event_appointment) {
                    return ['status' => 'error', 'message' => ['You have a appointment scheduled between ' . $model->start . ' to ' . $model->end . '.']];
                }
            }
        }
    }
 
}
